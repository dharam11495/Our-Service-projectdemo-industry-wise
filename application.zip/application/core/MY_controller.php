<?php

class MY_controller extends CI_Controller

{

 public function  _construct()

 {

 	echo "testing";
   // if (!this->isauthorized() { return redirect 'home'; } 
 }

}