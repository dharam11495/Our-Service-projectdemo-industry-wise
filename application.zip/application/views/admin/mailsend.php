


<?php include('header.php'); ?>

<div class="row">


	<div class="col-xl-4 mb-30">
		<h6>Template</h6>
			<ul class="list-unstyled">
				<li class="mb-30 button button-border btn-block"><a href="">Deepawali</a></li>
				<li class="mb-30 button button-border btn-block"><a href="">New Year</a></li>
				<li class="mb-30 button button-border btn-block"><a href="">Template</a></li>
				<li class="mb-30 button button-border btn-block"><a href="">Template</a></li>
				<li class="mb-30 button button-border btn-block"><a href="">Template</a></li>				
			</ul>
		
	</div>
	<div class="col-xl-8 mb-30">
		<div class="card "> 
          <div class="card-body">
          	 <?php  echo form_open('admin/newmailsend'); ?>
            
           
             <div class="col-xl-12">

			<div class="card-body">
			<h5 class="card-title">Mail Send New  </h5>
			
			
			<div class="form-group row">
			<label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">To</label>
			<div class="col-sm-10">
			<input type="email" class="form-control form-control-lg" id="colFormLabelLg" name="email">
			</div>
			</div>

			<div class="form-group row">
			<label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">Subject</label>
			<div class="col-sm-10">
			<input type="text" class="form-control form-control-lg" id="colFormLabelLg" name="subject">
			</div>
			</div>

			<div class="form-group row">
			<label for="colFormLabelLg" class="col-sm-2 col-form-label col-form-label-lg">Body</label>
			<div class="col-sm-10">
            <textarea id="textarea" rows="12" name="mailbody"></textarea>

            <?php  echo form_upload(['name'=>'userfile[]','multiple'=>'multiple']); ?>

			</div>
			</div>
			
			</div>
                
             </div>



             
             
             
             <div class="col-xl-2"><button type="submit" class="button btn-primary">Send</button></div>
              
         
           <?php   echo form_close(); ?>
             

           
      </div>
		
	</div>
</div>






<?php include('footer.php'); ?>


