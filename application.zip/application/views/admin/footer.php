
   
    </div><!-- main content wrapper end-->
  </div>
 </div>
</div>



<div class="style-customizer closed">
  <a class="opener" href="#"><i class="fa fa-cog fa-spin"></i></a> 
    <div class="clearfix content-chooser">
      <h5>Template Customizer </h5>
      <p>Customize & Preview in Real Time</p>
      <h5 class="mt-30"> Sidebar skins</h5>
      <ul class="list-unstyled mb-30">
        <li>
         <input type="radio" id="f-option" value="0" checked="" name="sidebarnar_skin" />
          <label for="f-option">Dark</label>
          <div class="check"></div>
       </li>
       <li>
        <input type="radio" id="s-option" value="1"  name="sidebarnar_skin" />
          <label for="s-option">light</label>
          <div class="check"><div class="inside"></div></div>
       </li>
      </ul>
      <h5 class="mt-20"> Header skins</h5>
      <ul class="list-unstyled mb-40">
        <li>
         <input type="radio" id="t-option" value="1" name="header_skin" />
          <label for="t-option">Dark</label>
          <div class="check"></div>
       </li>
       <li>
        <input type="radio" id="r-option" value="0" checked="" name="header_skin" />
          <label for="r-option">light</label>
          <div class="check"><div class="inside"></div></div>
       </li>
      </ul>
  </div>
</div>
<!-- jquery -->
<script src="<?= base_url('assets/js/jquery-3.3.1.min.js'); ?>"></script>

<!-- plugins-jquery -->
<script src="<?= base_url('assets/js/plugins-jquery.js'); ?>"></script>

<!-- plugin_path -->
<script>var plugin_path = 'js/index.html';</script>

<!-- chart -->
<script src="<?= base_url('assets/js/chart-init.js'); ?>"></script>

<!-- calendar -->
<script src="<?= base_url('assets/js/calendar.init.js'); ?>"></script>

<!-- charts sparkline -->
<script src="<?= base_url('assets/js/sparkline.init.js'); ?>"></script>

<!-- charts morris -->
<script src="<?= base_url('assets/js/morris.init.js'); ?>"></script>

<!-- datepicker -->
<script src="<?= base_url('assets/js/datepicker.js'); ?>"></script>

<!-- sweetalert2 -->
<script src="<?= base_url('assets/js/sweetalert2.js'); ?>"></script>

<!-- toastr -->
<script src="<?= base_url('assets/js/toastr.js'); ?>"></script>

<!-- validation -->
<script src="<?= base_url('assets/js/validation.js'); ?>"></script>

<!-- lobilist -->
<script src="<?= base_url('assets/js/lobilist.js'); ?>"></script>
 
<!-- custom -->
<script src="<?= base_url('assets/js/custom.js'); ?>"></script>


  
</body>

<!-- Mirrored from themes.potenzaglobalsolutions.com/html/webmin-bootstrap-4-angular-5-admin-dashboard-template/html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 26 Jul 2018 06:40:34 GMT -->
</html>